﻿using System;
using System.Collections.Generic;
using System.Text;
namespace CSLight
{

    public class CLS_Expression_SelfOp : ICLS_Expression
    {

        //Block的参数 一个就是一行，顺序执行，没有
        public List<ICLS_Expression> listParam
        {
            get
            {
                return null;
            }
        }

        public CLS_Content.Value ComputeValue(CLS_Content content)
        {
            var v = content.Get(value_name);
            ICLS_Type type = content.environment.GetType(v.type);
            Type returntype;
            object value = type.Math2Value(content.environment,mathop, v.value, CLS_Content.Value.One, out returntype);
            value = type.ConvertTo(content.environment, value, v.type);
            content.Set(value_name, value);

            //操作变量之
            //做数学计算
            //从上下文取值
            //_value = null;
            return null;
        }

  
        public string value_name;
        public char mathop;
  
        public override string ToString()
        {
            return "MathSelfOp|" + value_name + mathop;
        }
    }
}