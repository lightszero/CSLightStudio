﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class com_main : MonoBehaviour, MyType
{

    // Use this for initialization
    void Start()
    {
        scriptmgr = new MyScriptMgr();
        scriptmgr.Init();

        //作为代码
        //scriptmgr.SetCodeFile("testcode01", new CSLight.Framework.CodeFile_Debug<MyType>(scriptmgr, "testcode01", typeof(testcode01)));


        //作为脚本
        string codefile = Application.streamingAssetsPath + "/scripts/testcode01.cs";
        string code = System.IO.File.ReadAllText(codefile);
        scriptmgr.SetCodeFile("testcode01", new CSLight.Framework.CodeFile_CLScript<MyType>(scriptmgr, "testcode01", code));


        script = scriptmgr.GetCodeFile("testcode01");
        script.New(this);

    }
    MyScriptMgr scriptmgr = null;
    // Update is called once per frame
    float timer = 0;
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > 1.0f)
        {
            timer -= 1.0f;
            if (script != null)
            {
                script.CallScriptFuncWithParamString("_update", DateTime.Now.ToString());
            }
        }
    }
    void OnGUI()
    {
        if (GUI.Button(new Rect(0, 0, 150, 25), "call script _click01"))
        {
            if (script != null)
            {
                script.CallScriptFuncWithoutParam("_click01");
            }
        }
        if (GUI.Button(new Rect(150, 0, 150, 25), "call script _click02"))
        {
            if (script != null)
            {
                script.CallScriptFuncWithParamString("_click02", "000");
            }
        }
        if (GUI.Button(new Rect(300, 0, 150, 25), "call script _click03"))
        {

            if (script != null)
            {
                List<string> ss = new List<string>();
                ss.Add("123");
                ss.Add("567");
                script.CallScriptWithParamStrings("_click03", ss);
            }
        }

        int y = 100;
        foreach (var l in list)
        {
            GUI.Label(new Rect(0, y, 100, 25), l);
            y += 25;
        }
    }
    List<string> list = new List<string>();
    public void AddTextToList(string str)
    {
        list.Add(str);
    }
    Color color = Color.white;
    public void SetColorRed()
    {
        color = Color.red;
    }

    public void SetColorBlue()
    {
        color = Color.blue;
    }

    public CSLight.Framework.ICodeFile<MyType> script
    {
        get;
        private set;
    }
}
public interface MyType
{
    void AddTextToList(string str);
    void SetColorRed();
    void SetColorBlue();

    CSLight.Framework.ICodeFile<MyType> script
    {
        get;
    }
}

public class MyScriptMgr : CSLight.Framework.ScriptMgr<MyType>    //自定义自己的脚本管理器
{
    public override void Init()
    {
        base.Init();
        this.scriptEnv.RegType(new CSLight.RegHelper_Type(typeof(MyType)));
    }
}
