﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
public class CLComponent
{

    // Use this for initialization
    void Start()
    {
        Debug.Log("CLCompddffonent Start");
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void TestFun()
    {
        Debug.Log("Testfun called");
    }
}