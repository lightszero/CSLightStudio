﻿
using System.Collections;

public class Script_TestConstructor
{

    private int a;

    public Script_TestConstructor()
    {

    }

    public void Test()
    {

    }
}
