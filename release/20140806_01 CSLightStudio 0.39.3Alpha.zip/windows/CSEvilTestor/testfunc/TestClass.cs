﻿using CSEvilTestor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    public class TestClass
    {

        public string name
        {
            get
            {
                return "hi";
            }
            set
            {
                Debug.Log(value);
            }
        }
        public string ttc = "123";
    }
