﻿using CSEvilTestor;
//using CSEvilTestor;
using System;
using System.Collections.Generic;
using System.Text;

class Test01
{
    public static void Run()
    {
        Debug.Log("Hello world.");
    }
}

