﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CLScriptExt
{
    enum Country
    {
        Chinese,
        English,
        Japnese,
    };

}
