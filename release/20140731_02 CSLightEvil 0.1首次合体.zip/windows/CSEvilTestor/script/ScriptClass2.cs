﻿using System;
using System.Collections.Generic;
using System.Text;


class ScriptClass2
{
    static ScriptClass2 sc = new ScriptClass2();

    public int i = 3;
    public ScriptClass2()
    {

    }

}

